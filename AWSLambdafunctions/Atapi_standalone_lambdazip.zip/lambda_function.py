import alertlabapi as atapi
import common_functions as cf
import pandas as pd
import json

def lambda_handler(event, context):
    """
    Fetches data only from Alert Labs.
    """
    try:
        month_start, month_end = cf.get_firstandlastdayofpreviousmonth()
        master_df = cf.get_master_df()

        token = atapi.get_token()
        property_name = 'BGO Eglinton Town Centre (24)'
        property_id = atapi.get_property_id(token, property_name)
        if property_id is None:
            return {"statusCode": 500, "body": "No valid location found in Alert Labs."}

        sensor_list_df = atapi.get_sensorlist(token, property_id)
        sensorstoquery = dict(zip(sensor_list_df['_id'], sensor_list_df['name']))

        for sensor_id in sensorstoquery.keys():
            timeseries_df = atapi.get_timeseries_data(token, sensor_id, sensorstoquery, month_start, month_end)
            master_df = cf.mergewithmasterdf(master_df, timeseries_df)

        master_df = cf.add_summary_rows(master_df)
        csv_string = master_df.to_csv(index=False)
        response_body = {"property_name": property_name, "csv_data": csv_string}

        return {"statusCode": 200, "headers": {"Content-Type": "application/json"}, "body": json.dumps(response_body)}

    except Exception as e:
        return {"statusCode": 500, "body": f"Unexpected error: {str(e)}"}