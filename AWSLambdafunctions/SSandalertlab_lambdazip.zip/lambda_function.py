import asyncio
import json
import pandas as pd
import simplesubapi as ssapi
import alertlabapi as atapi
import common_functions as cf
import os

# Async function to fetch Alert Labs data with rate limiting
async def fetch_alertlabs_data(token, sensorstoquery, month_start, month_end, semaphore):
    # Local merged dataframe for Alert Labs data; start with an empty master DF
    alert_df = cf.get_master_df()
    
    async def get_data(sensor_id):
        async with semaphore:
            await asyncio.sleep(1)  # 1 second delay per Alert Labs request
            try:
                # Synchronous call run in a thread
                timeseries_df = await asyncio.to_thread(
                    atapi.get_timeseries_data,
                    token, sensor_id, sensorstoquery, month_start, month_end
                )
                return timeseries_df
            except Exception as e:
                print(f"Error fetching sensor {sensor_id}: {e}")
                return None

    tasks = [get_data(sensor_id) for sensor_id in sensorstoquery.keys()]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    for df in results:
        if isinstance(df, pd.DataFrame) and not df.empty:
            alert_df = cf.mergewithmasterdf(alert_df, df)
    return alert_df

# Async function to fetch SimpleSub data with rate limiting
async def fetch_simplesub_data(ss_token, unit_ids, month_start, month_end, semaphore):
    # Local merged dataframe for SimpleSub data; start with an empty master DF
    ss_df = cf.get_master_df()

    async def get_data(unit):
        async with semaphore:
            await asyncio.sleep(0.5)  # 0.5 second delay per SimpleSub request
            try:
                timeseries = await asyncio.to_thread(
                    ssapi.get_timeseries_data, unit, ss_token, month_start, month_end
                )
                if timeseries is None:
                    return None
                unit_name = timeseries.get("unit_name", f"Unit {unit}")
                if "devices" not in timeseries or not timeseries["devices"]:
                    return None
                # Handle merging for multiple devices if necessary
                if len(timeseries['devices']) > 1:
                    mergeddata = {}
                    for device in timeseries['devices']:
                        for entry in device['daily_usages']:
                            mergeddata[entry['date']] = mergeddata.get(entry['date'], 0) + entry['volume']
                    daily_usage = [{'date': k, 'volume': v} for k, v in mergeddata.items()]
                else:
                    daily_usage = timeseries["devices"][0].get("daily_usages", [])
                if not daily_usage:
                    return None
                df = pd.DataFrame(daily_usage)
                df.rename(columns={"volume": unit_name, "date": "Date"}, inplace=True)
                df["Date"] = pd.to_datetime(df["Date"])
                return df
            except Exception as e:
                print(f"Error fetching unit {unit}: {e}")
                return None

    tasks = [get_data(unit) for unit in unit_ids]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    for df in results:
        if isinstance(df, pd.DataFrame) and not df.empty:
            ss_df = cf.mergewithmasterdf(ss_df, df)
    return ss_df

async def main():
    # Define date range once
    month_start, month_end = cf.get_firstandlastdayofpreviousmonth()
    # Create a master DataFrame only once
    master_df = cf.get_master_df()
    property_name = 'BGO Pen Center'
    # Set up Alert Labs: get token, property, and sensor list mapping
    alert_token = atapi.get_token()
    property_id = atapi.get_property_id(alert_token, property_name=property_name)
    if property_id is None:
        raise ValueError("No valid location found for Alert Labs.")
    sensor_list_df = atapi.get_sensorlist(alert_token, property_id)
    sensorstoquery = dict(zip(sensor_list_df['_id'], sensor_list_df['name']))
    
    # Set up SimpleSub: get token, property list and unit IDs
    ss_token = ssapi.get_token()
    ss_properties = ssapi.get_property_list(ss_token)
    property_name = 'Pen Centre'
    unit_ids = ssapi.get_unit_ids_for_property(ss_properties, property_name)
    
    # Define semaphores for rate limiting:
    alert_semaphore = asyncio.Semaphore(1)  # 1 concurrent request for Alert Labs
    ss_semaphore = asyncio.Semaphore(1)     # 1 concurrent request for SimpleSub
    
    # Run both API loops concurrently
    alert_task = fetch_alertlabs_data(alert_token, sensorstoquery, month_start, month_end, alert_semaphore)
    ss_task = fetch_simplesub_data(ss_token, unit_ids, month_start, month_end, ss_semaphore)
    
    alert_df, ss_df = await asyncio.gather(alert_task, ss_task)
    
    # Merge results into the master DataFrame defined in main
    master_df = cf.mergewithmasterdf(master_df, alert_df)
    master_df = cf.mergewithmasterdf(master_df, ss_df)
    master_df = cf.add_summary_rows(master_df)
    
    # Save CSV file (ensure output directory exists)
    os.makedirs("csvs", exist_ok=True)
    master_df.to_csv(f"csvs/{property_name} monthly report.csv", index=False)
    print("CSV saved successfully.")

def lambda_handler(event, context):
    asyncio.run(main())
    return {"statusCode": 200, "body": "CSV report generated successfully."}

if __name__ == "__main__":
    asyncio.run(main())
