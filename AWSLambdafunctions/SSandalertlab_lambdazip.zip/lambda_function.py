import asyncio
import time
import simplesubapi as ssapi
import alertlabapi as atapi
import common_functions as cf
import pandas as pd
import json

# Helper functions to wrap the synchronous API calls

def fetch_alertlabs_single(sensor_id, token, sensorstoquery, month_start, month_end):
    """
    Calls the synchronous Alert Labs API function and then sleeps for 1 second
    to respect the rate limit.
    """
    try:
        result = atapi.get_timeseries_data(token, sensor_id, sensorstoquery, month_start, month_end)
        time.sleep(1)  # Maintain rate limit
        return result
    except Exception as e:
        return e

def fetch_simplesub_single(unit, ss_token, month_start, month_end):
    """
    Calls the synchronous SimpleSub API function and then sleeps for 1 second.
    Returns a tuple (unit, timeseries) so we can preserve the unit info.
    """
    try:
        timeseries = ssapi.get_timeseries_data(unit, ss_token, month_start=month_start, month_end=month_end)
        time.sleep(1)  # Maintain rate limit
        return (unit, timeseries)
    except Exception as e:
        return e

# Async functions that schedule the above helpers concurrently

async def fetch_alertlabs_all(token, sensorstoquery, month_start, month_end):
    tasks = []
    for sensor_id in sensorstoquery.keys():
        tasks.append(asyncio.to_thread(fetch_alertlabs_single, sensor_id, token, sensorstoquery, month_start, month_end))
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return results

async def fetch_simplesub_all(ss_token, unit_ids, month_start, month_end):
    tasks = []
    for unit in unit_ids:
        tasks.append(asyncio.to_thread(fetch_simplesub_single, unit, ss_token, month_start, month_end))
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return results

async def process_data():
    try:
        # Get date range and initialize master DataFrame
        month_start, month_end = cf.get_firstandlastdayofpreviousmonth()
        master_df = cf.get_master_df()

        # --- ALERT LABS DATA ---
        token = atapi.get_token()
        property_id = atapi.get_property_id(token, 'BGO Pen Center')
        if property_id is None:
            return {"statusCode": 500, "body": "No valid location found in Alert Labs."}

        sensor_list_df = atapi.get_sensorlist(token, property_id)
        sensorstoquery = dict(zip(sensor_list_df['_id'], sensor_list_df['name']))

        # Run all Alert Labs API calls concurrently
        alert_results = await fetch_alertlabs_all(token, sensorstoquery, month_start, month_end)
        for result in alert_results:
            if isinstance(result, Exception):
                continue  # Skip errors; you could also log these
            master_df = cf.mergewithmasterdf(master_df, result)

        # --- SIMPLESUB DATA ---
        ss_token = ssapi.get_token()
        ss_properties = ssapi.get_property_list(ss_token)
        property_name = 'Pen Centre'  # Change as needed
        unit_ids = ssapi.get_unit_ids_for_property(ss_properties, property_name)

        # Run all SimpleSub API calls concurrently
        simplesub_results = await fetch_simplesub_all(ss_token, unit_ids, month_start, month_end)
        for res in simplesub_results:
            # Skip if an exception occurred
            if isinstance(res, Exception):
                continue
            # Unpack the tuple (unit, timeseries)
            unit, timeseries = res
            if not timeseries or "devices" not in timeseries or not timeseries["devices"]:
                continue  # Skip units with no data
            daily_usage = timeseries["devices"][0].get("daily_usages", [])
            if not daily_usage:
                continue  # Skip empty data
            df = pd.DataFrame(daily_usage)
            unit_name = timeseries.get("unit_name", f"Unit {unit}")
            df.rename(columns={"volume": unit_name, "date": "Date"}, inplace=True)
            df["Date"] = pd.to_datetime(df["Date"])
            master_df = cf.mergewithmasterdf(master_df, df)

        # Add summary rows and convert to CSV
        master_df = cf.add_summary_rows(master_df)
        csv_string = master_df.to_csv(index=False)

        response_body = {
            "property_name": "BGO Pen Center",
            "csv_data": csv_string
        }

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(response_body)
        }
    except Exception as e:
        return {"statusCode": 500, "body": f"Unexpected error: {str(e)}"}

def lambda_handler(event, context):
    """
    AWS Lambda entry point.
    """
    try:
        return asyncio.run(process_data())
    except Exception as e:
        return {"statusCode": 500, "body": f"Unexpected error: {str(e)}"}
