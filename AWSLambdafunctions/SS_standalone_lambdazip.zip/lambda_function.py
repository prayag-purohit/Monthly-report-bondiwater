import simplesubapi as ssapi
import common_functions as cf
import pandas as pd
import time
import json
from collections import defaultdict

def lambda_handler(event, context):
    """
    Fetches data only from SimpleSub and returns it as JSON with CSV data.
    """

    try:
        month_start, month_end = cf.get_firstandlastdayofpreviousmonth()
        master_df = cf.get_master_df()
        ss_token = ssapi.get_token()
        ss_properties = ssapi.get_property_list(ss_token)
        property_name = '5731 Hwy 7'

        unit_ids = ssapi.get_unit_ids_for_property(ss_properties, property_name)

        

        for unit in unit_ids:
            try:
                timeseries = ssapi.get_timeseries_data(unit, ss_token, month_start=month_start, month_end=month_end)
                time.sleep(0.5)

                if timeseries is None:
                    print(f"Warning: No timeseries data returned for unit {unit}. Skipping...")
                    continue

                unit_name = timeseries.get("unit_name", f"Unit {unit}")
                devices = timeseries.get("devices", [])
                if not devices:
                    print(f"Warning: No devices data found for unit {unit}. Skipping...")
                    devices
                    continue

                if len(timeseries['devices']) > 1:
                    mergeddata = defaultdict(float)
                    for device in timeseries['devices']:
                        for entry in device['daily_usages']:
                            mergeddata[entry['date']] += entry['volume']
                            
                    daily_usage = [{'date': k, 'volume': v} for k, v in mergeddata.items()]
                else:
                    daily_usage = timeseries["devices"][0].get("daily_usages", [])
                    
                if not daily_usage:
                    print(f"Warning: No daily usage data for unit {unit}. Skipping...")
                    continue

                df = pd.DataFrame(daily_usage)
                df.rename(columns={"volume": unit_name, "date": "Date"}, inplace=True)
                df["Date"] = pd.to_datetime(df["Date"])
                master_df = cf.mergewithmasterdf(master_df, df)
                

            except Exception as e:
                print(f"Failed to get timeseries data for unit {unit}: {e}")
                continue

        master_df = cf.add_summary_rows(master_df)
        csv_string = master_df.to_csv(index=False)

        response_body = {
            "property_name": property_name,
            "csv_data": csv_string
        }

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(response_body)
        }

    except Exception as e:
        return {"statusCode": 500, "body": f"Unexpected error: {str(e)}"}


